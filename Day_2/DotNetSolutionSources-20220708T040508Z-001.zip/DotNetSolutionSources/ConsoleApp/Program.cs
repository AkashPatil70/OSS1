﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Enter your First Name:");
            string firstName= Console.ReadLine();
            Console.WriteLine("Enter your Last Name:");
            string lastName = Console.ReadLine();

            Console.WriteLine("Enter your Contact Number:");
            string contactNumber = Console.ReadLine();


            Console.WriteLine();

            Console.ReadLine();

        }
    }
}
